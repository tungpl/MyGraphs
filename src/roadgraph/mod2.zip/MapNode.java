package roadgraph;

import java.util.ArrayList;
import java.util.List;

import geography.GeographicPoint;
import roadgraph.MapEdge;
/*
 * This is class to store list of edges bound to a specific Node (Vertex)
 */
public class MapNode {
	
	GeographicPoint location;
	List<MapEdge> edges;
	/**
	 * Constructor method to create an empty MapNode
	 */
		public MapNode(){
		location =null;
		edges = new ArrayList<MapEdge>();
	}
// getter and setter methods
	public GeographicPoint getLocation() {
		return location;
	}

	public void setLocation(GeographicPoint location) {
		this.location = location;
	}

	public List<MapEdge> getEdges() {
		return edges;
	}

	public void setEdges(List<MapEdge> edges) {
		this.edges = edges;
	}
	
	
}
